angular.module('app.controllers', [])
  
.controller('signUpCtrl', function($scope) {

})
   
.controller('page3Ctrl', function($scope) {

})
 